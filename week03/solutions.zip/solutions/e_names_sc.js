//	Author: 		Scott Cordle
//	Date: 			10/20/2014
//	Description: 	Exercise 4.9, pg. 193 of Sebesta
//
//	Filename: e_names_sc.js
//	Supporting Files: ex4_9.html 


// see pg. 169-172 of Sebesta
var list = new Array("Tsolman", "Robert", "Ryan", "Kenneth", "Tyler", "Phillip", "Russell", "Bradley", "Sarahy", "Michael", "Brian", "Kirk");

var output = e_names(list); //function call
document.write("There are " + output + " names in the list that end in either ie or y.");

function e_names(listOfNames) {
	var count = 0;
	
	for (var num = 0; num < listOfNames.length; num++)
	{
		searchie = listOfNames[num].search(/ie$/);
		searchy = listOfNames[num].search(/y$/);
      
		if(searchie > 0 || searchy > 0)
		{
			count++;
		}
	}
	return count;
}






















