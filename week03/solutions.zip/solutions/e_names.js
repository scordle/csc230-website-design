// Filename: e_names.js
// Author: Kirk Wyatt
// Date: 10/19/2014

var random_ass_names = new Array("Tony", "Julia", "Chris", "Ed", "Amy", "Katie");
var counts = e_names(random_ass_names);

function e_names(names) {
	var index, count = 0;
	for (index = 0; index < names.length; index++)
	{
		search1 = names[index].search(/ie$/);
		search2 = names[index].search(/y$/);
      
		if(search1+search2>-2)
		{
			count++;
		}
	}
	return count;
};

document.write('There are currently <strong>' + counts + '</strong> names in the array that end in either ie or y.');

