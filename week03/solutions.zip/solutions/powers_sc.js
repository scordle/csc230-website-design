//	Author: 		Scott Cordle
//	Date: 			10/19/2014
//	Description: 	Exercise 4.1, pg. 192 of Sebesta
//
//	Filename: 		ex4_1.html
//	Supporting Files: powers.js


var output = '';

for (var i = 5; i < 16; i++)
{
	output += '<tr><td>' + i + '</td><td>' + Math.pow(i,2) + '</td><td>' + Math.pow(i,3) + '</td></tr>';
}

document.write(output);



