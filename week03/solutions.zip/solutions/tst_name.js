// Filename: tst_name.js
// Author: Kirk Wyatt
// Date: 10/19/2014

function test_name(name){

var test = name.search(/^[A-Z][a-z,]+\s[A-Z][a-z]+\s[A-Z]/);
	if (test == 0)
	{ 
		return name + ' was in the correct format.';
	}
	else
	{ 
		return name + ' was not in the correct format.';
	}
}

var name1 = "Rico Suave";
var name2 = "Marks, Aaron L";
var name3 = "Etheridge, Melissa";

var name1_test = test_name(name1);
var name2_test = test_name(name2);
var name3_test = test_name(name3);

document.write(name1_test + '<br />' + name2_test + '<br />' + name3_test);
